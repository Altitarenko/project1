# Конфиг файлы с видео [HTTPS для ленивых](https://youtu.be/OgCXa7e-mO0)
В видео настраивается связка Docker-compose, nginx, mysql, php-fpm, wordpress, cerbot
