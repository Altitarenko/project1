# Конфиг файлы с видео [Web-сервер для ленивых](https://youtu.be/mKdwkV5p1xg)
В видео настраивается связка Docker-compose, nginx, mysql, php-fpm, wordpress