# Материалы для видео с канала [Мир IT c Антоном Павленко](https://www.youtube.com/c/pavlenkoat/)

## Навигация

Имя каждого подкаталога — это идентификатор видео на YouTube: `https://www.youtube.com/watch?v=<video id>`.

* [Web-сервер для ленивых](https://youtu.be/mKdwkV5p1xg), см. [mKdwkV5p1xg](./mKdwkV5p1xg/README.md).
* [HTTPS для ленивых](https://youtu.be/OgCXa7e-mO0), см. [OgCXa7e-mO0](./OgCXa7e-mO0/README.md).
* [CRON.D больше НЕ НУЖЕН. Как пользоваться SYSTEMD TIMER?](https://youtu.be/kfQEPxigNY4), см. [kfQEPxigNY4](./kfQEPxigNY4/README.md).
